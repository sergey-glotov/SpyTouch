import React from "react";

const AddButton = () => {
  const clickHandler = () => {

  };

  <div>
    <button type="button" onClick={clickHandler}>הוספת סוכן</button>
  </div>
};

export default AddButton;
